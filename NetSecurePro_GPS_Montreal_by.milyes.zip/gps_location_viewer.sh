#!/bin/bash
xdg-open 'https://www.google.com/maps?q=45.574944,-73.594000'