
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:convert';

void main() {
  runApp(VideoLauncherApp());
}

class VideoLauncherApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IA22 Video Launcher',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: FutureBuilder<String>(
            future: rootBundle.loadString('assets/video_launcher.html'),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                final url = Uri.dataFromString(
                  snapshot.data ?? '',
                  mimeType: 'text/html',
                  encoding: Encoding.getByName('utf-8'),
                ).toString();
                return WebView(
                  initialUrl: url,
                  javascriptMode: JavascriptMode.unrestricted,
                );
              } else {
                return Center(child: CircularProgressIndicator());
              }
            },
          ),
        ),
      ),
    );
  }
}
